clear all
close all

load timeSeriesAllSessions.mat


addpath ./..

dataAll = [];



    for roi = 1:40
    dataSes = [];
        sesId = [];
for ses = 1:55


        
        data = timeSeriesAllSessions{ses,roi};
        
        dataSes = cat(1,dataSes, data);

        sesId = cat(1,sesId,ses*ones(size(data,1),1));
end

dataAll(roi,:,:) = dataSes';

    end
    
    
    me = mean(dataAll(:,:),2);
    st = std(dataAll(:,:),[],2);
    
 %   dataAll = dataAll - repmat(mean(dataAll),[size(dataAll,1) 1 1]);
    
 %   imagesc(mean(dataAll,3))
    
    
    for trial = 1:size(dataAll,3)
       for roi = 1:size(dataAll,1)
        dataAll(roi,:,trial) = (dataAll(roi,:,trial) - me(roi))/st(roi);
     %   dataAll(roi,:,trial) = (dataAll(roi,:,trial) - dataAll(roi,1,trial))/st(roi);
       
       end
    end
    
    
    %%% clustering 

    
    n_clust = 6;

[id,clust] = traj_kmeans(dataAll,n_clust,1000);



figure
for clus = 1:n_clust
    
    subplot(2,3,clus)
    
    imagesc(clust(:,:,clus),[-1.5 1.5])
    title(['cluster ' num2str(clus) ',n trials: ' num2str(sum(id==clus))])
    axis square
end

figure

plot(squeeze(mean(clust)))

legend


for ses = 1:55
    
    for clus = 1:n_clust
        
        
        proba(ses,clus) = sum(id==clus & sesId'==ses)/sum(sesId==ses);
        
        
    end
end


        
        
    
    